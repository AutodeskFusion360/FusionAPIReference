import adsk.core, adsk.fusion, traceback
from datetime import datetime
import json

_app: adsk.core.Application = None
_ui: adsk.core.UserInterface  = None
_rowNumber = 0

# Global set of event handlers to keep them referenced for the duration of the command
_handlers = []


class MyCommandCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            # Get the command that was created.
            cmd = adsk.core.Command.cast(args.command)
            inputs: adsk.core.CommandInputs = cmd.commandInputs

            # Create a selection command input.
            inputs.addSelectionInput('select1', 'Face', 'Tool tip')

            # Create a browser command input to get the newsletter information.
            brInput1 = inputs.addBrowserCommandInput('registerBrowser', 'Newsletter', 'Resources/Register.htm', 28, 28)

            # Create a second selection command input.
            inputs.addSelectionInput('select2', 'Edge', 'Tool tip')

            # Create a second browser command input and set it to be full width.
            brInput5 = inputs.addBrowserCommandInput('tableBrowser', 'Table', 'Resources/TimeTable.htm', 100, 0)
            brInput5.isFullWidth = True

            # Add a button row command input with four buttons.
            buttonRow = inputs.addButtonRowCommandInput('timeButtons', 'Set Time', False)
            buttonRow.listItems.add('one', False, 'Resources/Pic1', -1)
            buttonRow.listItems.add('two', False, 'Resources/Pic2', -1)
            buttonRow.listItems.add('three', False, 'Resources/Pic3', -1)
            buttonRow.listItems.add('four', False, 'Resources/Pic4', -1)

            # Add a string value input that will be used to display messages.
            stringInput = inputs.addStringValueInput('stringInput', 'Message', '')
            stringInput.isReadOnly = True

            # Connect to the command destroyed event.
            onDestroy = MyDestroyHandler()
            cmd.destroy.add(onDestroy)
            _handlers.append(onDestroy)            

            # Connect to the input changed event.           
            onInputChanged = MyCommandInputChangedHandler()
            cmd.inputChanged.add(onInputChanged)
            _handlers.append(onInputChanged)

            # Connect to the incoming from HTML event associated with the command.
            incomingFromHTML = MyIncomingFromHTMLHandler()
            cmd.incomingFromHTML.add(incomingFromHTML)
            _handlers.append(incomingFromHTML)
        except:
            _ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))


# Event handler that reacts to any changes the user makes to any of the command inputs.
class MyCommandInputChangedHandler(adsk.core.InputChangedEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            eventArgs = adsk.core.InputChangedEventArgs.cast(args)
            inputs = eventArgs.inputs
            cmdInput = eventArgs.input

            # Check to see if the timer buttons were clicked.
            if eventArgs.input.id == 'timeButtons':
                buttonRow: adsk.core.ButtonRowCommandInput = eventArgs.input
                currentButton: adsk.core.ListItem = buttonRow.selectedItem

                # Get the current date and time and send information to the HTML that
                # it will use to update a cell in the table.
                now = datetime.now()
                current_time = now.strftime("%H:%M:%S")
                tableBrowser: adsk.core.BrowserCommandInput = inputs.itemById('tableBrowser')
                if currentButton.name == 'one':
                    tableBrowser.sendInfoToHTML('send', '1|{}'.format(current_time))
                elif currentButton.name == 'two':
                    tableBrowser.sendInfoToHTML('send', '2|{}'.format(current_time))
                elif currentButton.name == 'three':
                    tableBrowser.sendInfoToHTML('send', '3|{}'.format(current_time))
                elif currentButton.name == 'four':
                    tableBrowser.sendInfoToHTML('send', '4|{}'.format(current_time))
        except:
            _ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))


# Handle incoming data from all of the HTML inputs in the command.
class MyIncomingFromHTMLHandler(adsk.core.HTMLEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        eventArgs = adsk.core.HTMLEventArgs.cast(args)
        cmdInput = eventArgs.browserCommandInput

        # Check that the input is coming the "registerBrowser" BrowserCommandInput.
        if cmdInput.id == 'registerBrowser':
            # Extract the value from the data passed from the HTML.
            jsonString = eventArgs.data
            jsonData = json.loads(jsonString)
            registerValue = jsonData['registerData']

            # Set the value of the StringCommandInput to the retrieved value.
            stringInput = cmdInput.parentCommand.commandInputs.itemById('stringInput')
            stringInput.value = registerValue

            # Set the return value that wil be returned to the HTML.
            eventArgs.returnData = 'Success'


# Event handler for the destroy event.
class MyDestroyHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        eventArgs = adsk.core.CommandEventArgs.cast(args)

        # Terminate this command.
        adsk.terminate() 


def run(context):
    try:
        global _app, _ui
        _app = adsk.core.Application.get()
        _ui = _app.userInterface

        # Get the existing command definition or create it if it doesn't already exist.
        cmdDef = _ui.commandDefinitions.itemById('cmdBrowserInputSample')
        if not cmdDef:
            cmdDef = _ui.commandDefinitions.addButtonDefinition('cmdBrowserInputSample', 'Browser Input Sample', 'Browser Input Sample')

        # Connect to the command created event.
        onCommandCreated = MyCommandCreatedHandler()
        cmdDef.commandCreated.add(onCommandCreated)
        _handlers.append(onCommandCreated)

        # Execute the command definition and stop it from being terminated.
        cmdDef.execute()
        adsk.autoTerminate(False)
    except:
        if _ui:
            _ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))